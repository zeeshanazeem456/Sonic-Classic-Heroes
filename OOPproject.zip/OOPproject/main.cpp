#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>
#include "GameManager.h"
using namespace sf;
using namespace std;
int main() {
	GameManager game;
	game.playGame();
}